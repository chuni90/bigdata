package test;

public class Exam_01 {

	public static void main(String[] args) {
		System.out.println("Test");
	}
}
