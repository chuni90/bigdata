package mov.com.vo;

import static mov.com.db.JdbcUtils.close;
import static mov.com.db.JdbcUtils.getConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class AccountDAO {

	
	public ArrayList<AccountDTO> selectAllMoviee() {
	      
	      ArrayList<AccountDTO> list = new ArrayList<AccountDTO>();
	      String sql = "select * from account";
	      Connection conn = null;
	      PreparedStatement pstmt = null;
	      ResultSet rs = null;
	      AccountDTO dto = null;
	      
	      
	      try {
	    	 conn = getConnection();
	         pstmt = conn.prepareStatement(sql);
	         rs= pstmt.executeQuery();
	         
	         while(rs.next()) {
	               dto = new AccountDTO(
	                               rs.getString("id"),
	                               rs.getString("name"),
	                               rs.getString("mymovie"),
	                               rs.getString("power"));
	            list.add(dto);
	         }
	         
	         
	      }catch(Exception e) {
	         e.printStackTrace();
	         
	      }finally {
	    	  close(conn, pstmt, null);
	      }
	      return list;
	   }

	public int voteMovie(String movieId, String userId) {
	      String sql = "UPDATE account SET mymovie = ? WHERE id = ?";
	      Connection conn = null;
	      PreparedStatement pstmt = null;
	      int check = 0;
	      
	      try {
	         conn =getConnection();
	         pstmt = conn.prepareStatement(sql);
	         pstmt.setString(1, movieId);
	         pstmt.setString(2, userId);
	         check = pstmt.executeUpdate();
	      }catch(Exception e) {
	         System.out.println("오류 발생 >" + e.getMessage());
	         e.printStackTrace();
	      }finally {
	         close(conn, pstmt, null);
	      }
	      return check;
	}
	
}
